var applog = angular.module('myApp',['ngRoute']);

applog.config([ '$routeProvider', '$locationProvider',
    function($routeProvider, $locationProvider) {
        $routeProvider.when('/home', {
            templateUrl : 'home.html',
            controller : 'homeController'
        });
         $routeProvider.when('/results', {
            templateUrl : 'intres.html',
            controller : 'resultController'
        });
        $routeProvider.when('/', {
            templateUrl : 'login.html',
            controller : 'loginController'
        }).otherwise({
            redirectTo : 'index.html'
        });
        //$locationProvider.html5Mode(true); //Remove the '#' from URL.
    }
]);

applog.controller("loginController",['$scope','$location', function($scope, $location) {
     localStorage.removeItem('answers');
     localStorage.removeItem('username');
    $scope.login = function() {
        console.log("came");
       var username = $scope.username;
       if (username != "")
        {
            localStorage.setItem('username',username);
            $location.path("/home" );
        } 
    };
}]);

applog.controller("homeController",['$scope','$location','$http', function($scope, $location, $http) {

	$scope.username=localStorage.getItem('username');
    $scope.useranswers=[];
    $scope.curq =1;
    if( ! $scope.username || localStorage.getItem('answers'))
    {
        console.log("bug");
        localStorage.removeItem('answers');
        localStorage.removeItem('username');
        $location.path('/');
    }
    else
    {
        localStorage.removeItem('answers');
        $http.get('data/questions.json').then(function(response)
        {
            $scope.questions=response.data.questions;
            console.log($scope.questions);
            $scope.maxq = $scope.questions.length;
        })
    }
    $scope.submitanswer= function(canswer)
    {
        console.log(canswer);
        $scope.useranswers[($scope.curq)-1]=canswer;
        if($scope.curq == $scope.maxq)
        {  
             localStorage.setItem('answers',$scope.useranswers);
            $location.path('/results');
        }
        else
        {
            $scope.curq ++;
        }
        console.log($scope.useranswers);
    }

}]);

applog.controller("resultController",['$scope','$location', '$http', function($scope,$location, $http)
{
    init($scope);
    function init($scope)
    {
    if(!localStorage.getItem('answers'))
    {
        $location.path('/');
    console.log("will write");
    $scope.answers=$scope.user.answers;
    localStorage.setItem('answers',$scope.answers);
    $scope.user.answers=localStorage.getItem('answers');
    }
    else
    {
        $scope.useranswers=localStorage.getItem('answers');
    }
    $scope.curq =1;
    console.log($scope.useranswers);
    $scope.answersarray=$scope.useranswers.split(',');
    $scope.username=localStorage.getItem('username');
    if(! $scope.username)
    {
        $location.path('/')
    }
    else
    {
        $scope.usercorrect=0;
        $scope.userincorrect=0;
        $http.get('data/questions.json').then(function(response)
        {
            $scope.questions=response.data.questions;
            $scope.maxq = $scope.questions.length;
            var i=0;
        angular.forEach($scope.questions,function(question)
        {
            $scope.questions[i].useranswer = $scope.answersarray[i];
            console.log($scope.questions[i].useranswer+"   -  "
                +$scope.questions[i].correct);
            if($scope.questions[i].useranswer == $scope.questions[i].correct)
            {
                $scope.usercorrect++;
            }
            else
            {
                $scope.userincorrect++;
            }
            i++;
        });
        console.log($scope.questions);
        console.log($scope.usercorrect);
        console.log($scope.userincorrect);
         chart.data[0].dataPoints[0].y = parseInt($scope.usercorrect);
         chart.data[0].dataPoints[1].y = parseInt($scope.userincorrect);
         console.log(chart.data[0]);
         console.log(chart.data[0].dataPoints[0].y);
         console.log(chart.data[0].dataPoints[1].y);
         chart.render();
        });


        var chart = new CanvasJS.Chart("chartContainer",
    {
    animationEnabled: true,
    title:{
      text: "Results Summary"
    },
    data: [
    {
      type: "column", //change type to bar, line, area, pie, etc
      dataPoints: [
        { label: "Correct",y:15},
        { label: "Incorrect",y:14}
      ]
    }
    ]
    });
 
  
  chart.render();
        
    }

    }
$scope.redirectToIndex = function()
{
    localStorage.removeItem('answers');
    localStorage.removeItem('username');
    $location.path('/');
}

   

}]);



