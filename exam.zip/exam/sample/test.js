var applog = angular.module('myApp',['ngRoute']);

applog.config([ '$routeProvider', '$locationProvider',
    function($routeProvider, $locationProvider) {
        $routeProvider.when('/home', {
            templateUrl : 'home.html',
            controller : 'homeController'
        });
         $routeProvider.when('/results', {
            templateUrl : 'intres.html',
            controller : 'resultController'
        });
        $routeProvider.when('/', {
            templateUrl : 'login.html',
            controller : 'loginController'
        }).otherwise({
            redirectTo : 'index.html'
        });
        //$locationProvider.html5Mode(true); //Remove the '#' from URL.
    }
]);
